r""" 
A package for calculating transfer functions.
""" 
