r"""
Cosmological parameters from Planck. 
"""
