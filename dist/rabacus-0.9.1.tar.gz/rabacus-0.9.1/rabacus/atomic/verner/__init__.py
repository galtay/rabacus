"""
A package to handle the work of Dima Verner
http://www.pa.uky.edu/~verner/
"""

import photox
